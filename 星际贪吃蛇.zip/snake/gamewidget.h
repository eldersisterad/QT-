#ifndef GAMEWIDGET_H
#define GAMEWIDGET_H

#include <QWidget>
#include<QIcon>
#include<QPalette>
#include<QBrush>
#include<QPixmap>
#include<QPushButton>
#include<QMessageBox>
#include<QPaintEvent>
#include<QPainter>
#include<QLabel>
#include<QTimer>//计时器
#include<QTime>//随机函数头文件
#include<ctime>
#include<QButtonGroup>
#include<QKeyEvent>
#include<QStyle>
#define longnumber 20//定义游戏界面
#define widthnumber 16
class Gamewidget : public QWidget
{
    Q_OBJECT
public:
    explicit Gamewidget(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);
    void keyPressEvent(QKeyEvent *e);
    QPushButton *upPush;//方向键
    QPushButton *downPush;
    QPushButton *leftPush;
    QPushButton *rightPush;
    QPushButton *StartPush;//开始
    QPushButton *ExitPush;//退出
    QLabel *ScoreLabel;//分数标签
    QLabel *LevelLabel;//难度标签
    QLabel *ScoreLabelNumber;
    QLabel *LevelLabelNumber;
    QTimer *Timer;
    int snake[200][2];//创建了一个包含蛇的身体坐标的数组
    int snake1[200][2];//复制上一个坐标，用于在咬到身体或者撞到边缘时还原身体坐标
    static  int m_setDiretion;//对方向的更改的存储
    QButtonGroup *buttonGroup;//上下左右四个键构成一个按钮组，根据它们的返回值改变方向的值
    int foodx;//食物的X坐标
    int foody;//食物的Y坐标
    int bodycount;//身体长度
    bool Nobite;
    int Score;
    int Difficulty;//难度级别，时间变化
private:
    QPalette *palette;

signals:


public slots:
    void M_timeout();
    void M_startPush();
    void M_setDiretion(int index);
    void M_exitPush();
    void M_pausePush();
    void M_CheckGameOver();//检查是否咬到自己活着出界
};

#endif // GAMEWIDGET_H
